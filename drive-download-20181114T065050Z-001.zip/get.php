<?php
require 'connect.php';
$query="SELECT * FROM `sign`";
if($is_query_run=mysql_query($query))
{
echo "Query executed<br>";
while($query_execute=mysql_fetch_assoc($is_query_run))
{
echo '<table border="3"><tr><td>'.$query_execute['username'].'</td><td>'.$query_execute['password'].'</td></tr></table>';
//echo $query_execute['username'].'<br>';
}
}
else
{
    echo "query not executed";
}
?>