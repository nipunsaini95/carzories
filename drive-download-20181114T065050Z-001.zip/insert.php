<?php

$username = filter_input(INPUT_POST,'username');
$password = filter_input(INPUT_POST,'password');
if(!empty($username)){
if(!empty($password)){
$host="localhost";
$dbusername="root";
$dbpassword="";
$dbname="register1";
    
    
$conn= new mysqli ($host,$dbusername,$dbpassword,$dbname);    
     
    if(mysqli_connect_error()){
        die('Connect Error('.mysqli_connect_errno().')'.mysqli_connect_error());
    }
    else{
        $sql = "INSERT INTO sign (username,password) values('$username','$password')";
        if($conn->query($sql))
        {
            echo"New record inserted successfully";
        }
        else
        {
echo "Error:".$sql."<br>".$conn->error;
        }
        $conn->close;
    }
}
    else{
        echo"Password can't be empty";
        die();
    }
}
else{
    echo "UserName can't be empty";
    die();
}
    ?>