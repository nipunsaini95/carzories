<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>CARZORIES || LOGIN</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/w3.css">
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/function.js"></script>
    <link rel="stylesheet" href="css/layout.css">
   
</head>
<body>
<nav class="navbar navbar-inverse navbar-top" id="bar">
<div class="container-fluid">
<div class="navbar-header">
<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
         <span class="icon-bar"></span>
         <span class="icon-bar"></span>
         <span class="icon-bar"></span>
</button>
         <a class="navbar-brand" href="home.html" id="title"><b>CARZORIES</b></a>
</div>
<div class="collapse navbar-collapse" id="myNavbar">    
        <input type="search" placeholder="Search" size="60" align="center" id="box">
<ul class="nav navbar-nav navbar-right">
        <li><a href="login.html"><button type="button" class="btn btn-primary btn-md" id="bt">LOGIN</button></a></li>
        <li><a href="new.html"><button type="button" class="btn btn-primary active btn-md" id="bt">SIGN UP</button></a></li>
</ul>
</div>
</div>
</nav>
<div class="t4">
<form name="newform" method="post">
<table align="center">
<br><br><br><br>
<tr>
<td>
<h3>First Name :</h3></td><td>        <input type="text" size="30" name="fname" required>
</td>
</tr>
<tr>
<td>
<h3>Last Name  :</h3></td><td>           <input type="text" size="30" name="lname" required>
</td>
</tr>
<tr>
<td>
<h3>NickName   :</h3></td><td>           <input type="text" size="30" name="nname">
</td>
</tr>
<tr>
<td>
<h3>Date of Birth :</h3></td><td>      <input type="date" size="30" name="dob" required>
</td>
</tr>
<tr>
<td>
<h3>E-mail :</h3></td><td>               <input type="email" size="30" placeholder="example@example.com" name="username" required>
</td>
</tr>
    <tr>
<td>
<h3>Contact No :</h3></td><td>        <input type="text" size="30" name="contno" required>
</td>
</tr>
    <tr>
<td>
<h3>Address :</h3></td><td>        <input type="textfield" size="30" name="address" required>
</td>
</tr>
<tr>
<br><br><br>
<td colspan="2" align="center">
<input type="submit" value="SUBMIT" onClick="register()">
</td>
</tr>
    </table>
    </form>
</div>

    <?php
$con= mysqli_connect("localhost","root","register1","newuser");
$fname=$_POST["fname"];
$lname=$_POST["lname"];
$dob=$_POST["dob"];
$email=$_POST["username"];
$cont=$_POST["contno"];
$add=$_POST["address"];

if(!mysqli_connect_errno())
{
    mysqli_query($con,"INSERT INTO empreg (fname,lname,dob,username,contno,address) VALUES ('$fname','$lname','$dob','$email','$cont','$add')");

    echo "<script type='text/javascript'>alert(\"Record inserted successfully\");</script>";
}
else
{
    echo "failed to connect to D/B: ".mysqli_connect_error();

}
mysqli_close($con);
?>
    </body>
</html>